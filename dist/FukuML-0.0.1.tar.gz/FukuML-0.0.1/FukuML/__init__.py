#encoding=utf8

__version__ = '0.0.1'
__all__ = ['Machine Learning', 'Perceptron Learning Algorithm', 'PLA']
